import styles from "./index.module.css";

const Desktop2 = () => {
  return (
    <div className={styles.desktop2}>
      <img className={styles.removal2Icon} alt="" src="../removal-2@2x.png" />
      <button className={styles.services}>
        <button className={styles.services1}>Services</button>
      </button>
      <button className={styles.about}>
        <div className={styles.about1}>
          <p className={styles.blog}>About</p>
        </div>
      </button>
      <button className={styles.about3}>
        <div className={styles.homedefault}>
          <div className={styles.about1}>
            <p className={styles.blog}>Blog</p>
          </div>
        </div>
      </button>
      <button className={styles.home}>
        <div className={styles.homedefault}>
          <div className={styles.homedefault}>
            <div className={styles.home2}>Home</div>
          </div>
        </div>
      </button>
      <div className={styles.weHelpYou}>
        We help you go from Zero to 1 for your next Big Thing.
      </div>
      <div className={styles.startYourStartupContainer}>
        <p className={styles.startYourStartup}>
          Start your Startup or Business with ease.
        </p>
        <p
          className={styles.startYourStartup}
        >{`Take the hassle out of entrepreneurship `}</p>
        <p className={styles.startYourStartup}>with our innovative platform.</p>
        <p className={styles.startYourStartup}>&nbsp;</p>
        <p className={styles.startYourStartup}>&nbsp;</p>
        <p className={styles.startYourStartup}>&nbsp;</p>
        <p className={styles.p}>{`                                       `}</p>
      </div>
      <button className={styles.rectangle152default}>
        <button className={styles.vectorParent}>
          <button className={styles.instanceChild} />
          <button className={styles.getStarted}>Learn more</button>
        </button>
      </button>
      <img className={styles.desktop2Child} alt="" src="../rectangle-34.svg" />
      <img className={styles.desktop2Item} alt="" src="../rectangle-15.svg" />
      <button className={styles.vectorGroup}>
        <button className={styles.instanceChild} />
        <button className={styles.getStarted1}>Get started</button>
      </button>
      <img className={styles.desktop2Inner} alt="" src="../group-1.svg" />
      <button className={styles.vectorContainer}>
        <button className={styles.instanceInner} />
        <button className={styles.validateYourIdea}>Validate your idea</button>
      </button>
      <b className={styles.ourServices}>OUR SERVICES</b>
      <div className={styles.whatWeOffer}>What we offer for you</div>
      <div className={styles.frameDiv} />
      <img className={styles.rectangleIcon} alt="" src="../rectangle-12.svg" />
      <div className={styles.groupParent}>
        <img className={styles.frameChild} alt="" src="../group-2.svg" />
        <div className={styles.validateYourIdeaContainer}>
          <p className={styles.conductingAMarket}>{`Validate your idea by `}</p>
          <p className={styles.conductingAMarket}>{`conducting a market `}</p>
          <p className={styles.p}>survey in our platform.</p>
        </div>
        <img className={styles.frameItem} alt="" src="../rectangle-153.svg" />
      </div>
      <button className={styles.conductSurvey}>Conduct survey</button>
      <div className={styles.wereASaas}>
        We're a SaaS company that's dedicated to empowering entrepreneurship by
        making it easier and more reliable to start up a business.
      </div>
      <div className={styles.aboutUs}>About us</div>
      <img
        className={styles.desktop2Child1}
        alt=""
        src="../rectangle-8@2x.png"
      />
      <img className={styles.vectorIcon} alt="" src="../vector.svg" />
      <div className={styles.launchYourProductContainer}>
        <p className={styles.blog}>Launch your product</p>
        <p className={styles.blog}>and get your initial</p>
        <p className={styles.p}>set of users.</p>
      </div>
      <img className={styles.desktop2Child2} alt="" src="../rectangle-35.svg" />
      <button className={styles.comingSoon}>Coming soon</button>
      <img
        className={styles.businessTeam51Icon}
        alt=""
        src="../business-team-5-1@2x.png"
      />
      <div className={styles.ourPlatformLets}>
        Our platform lets you validate your concept, and launch your product
        through our launch pad with experienced founders and startups community.
      </div>
      <div className={styles.whyUs}>
        <p className={styles.startYourStartup}>
          <span>Why us</span>
        </p>
        <p className={styles.p1}>
          <span>{`   `}</span>
        </p>
      </div>
      <div className={styles.ourWork}>
        <p className={styles.startYourStartup}>
          <span>Our work</span>
        </p>
        <p className={styles.p1}>
          <span>{`     `}</span>
        </p>
      </div>
      <div className={styles.wereBuildingAnContainer}>
        <p className={styles.startYourStartup}>
          We’re building an ecosystem with our technology, helping you
        </p>
        <p
          className={styles.startYourStartup}
        >{`start at an affordable cost while streamlining the process of `}</p>
        <p className={styles.startYourStartup}>starting your Startup.</p>
      </div>
      <img className={styles.ellipseIcon} alt="" src="../ellipse-1.svg" />
      <img className={styles.desktop2Child3} alt="" src="../ellipse-2.svg" />
      <img className={styles.desktop2Child4} alt="" src="../ellipse-3.svg" />
      <img className={styles.polygonIcon} alt="" src="../polygon-1.svg" />
      <img className={styles.desktop2Child5} alt="" src="../ellipse-4.svg" />
      <img className={styles.desktop2Child6} alt="" src="../ellipse-5.svg" />
      <img className={styles.desktop2Child7} alt="" src="../polygon-2.svg" />
      <img className={styles.desktop2Child8} alt="" src="../ellipse-4.svg" />
      <img className={styles.desktop2Child9} alt="" src="../polygon-3.svg" />
      <img className={styles.vectorIcon1} alt="" src="../vector1.svg" />
      <img className={styles.approvalIcon} alt="" src="../approval@2x.png" />
      <img className={styles.desktop2Child10} alt="" src="../ellipse-7.svg" />
      <b className={styles.conductYourSurvey}>
        CONDUCT YOUR SURVEY AND VALIDATE YOUR IDEA
      </b>
      <div className={styles.removal6Wrapper}>
        <img className={styles.removal6Icon} alt="" src="../removal-6@2x.png" />
      </div>
      <div className={styles.validHelpsEntrepreneurs}>
        Valid helps entrepreneurs validate their ideas and validate the market
        faster with real-time data.
      </div>
      <div className={styles.getTheMarket}>
        Get the market insights in your inbox.
      </div>
      <div className={styles.desktop2Inner1}>
        <div className={styles.frameInner} />
      </div>
      <div className={styles.company}>Company</div>
      <div className={styles.social}>Social</div>
      <button className={styles.blog1}>Blog</button>
      <button className={styles.services2}>Services</button>
      <button className={styles.aboutUs1}>About us</button>
      <button className={styles.contactUs}>Contact us</button>
      <a className={styles.linkedin1} />
      <a className={styles.twitter1} />
      <a className={styles.instagram1} />
      <div className={styles.copyright2023Valid}>
        Copyright 2023 Valid. All Rights Reserved
      </div>
      <img className={styles.copyrightIcon} alt="" src="../copyright@2x.png" />
      <div className={styles.v}>{`V  `}</div>
      <b className={styles.turnYourIdea}>Turn your Idea into Reality</b>
      <b className={styles.alid}>alid</b>
      <div className={styles.v1}>{`V  `}</div>
      <b className={styles.turnYourIdea1}>Turn your Idea into Reality</b>
      <b className={styles.alid1}>alid</b>
      <div className={styles.v2}>{`V  `}</div>
      <b className={styles.alid2}>alid</b>
      <div className={styles.v3}>{`V  `}</div>
      <b className={styles.alid3}>alid</b>
      <div className={styles.v4}>{`V  `}</div>
      <b className={styles.alid4}>alid</b>
      <img
        className={styles.desktop2Child11}
        alt=""
        src="../rectangle-81@2x.png"
      />
      <div className={styles.launchYourProductContainer1}>
        <span className={styles.launchYourProductContainer2}>
          <p className={styles.conductingAMarket}>{`Launch your product `}</p>
          <p className={styles.conductingAMarket}>{`on our launchpad `}</p>
          <p className={styles.p}>with huge community.</p>
        </span>
      </div>
      <div className={styles.comingSoon1}>Coming soon</div>
      <img
        className={styles.desktop2Child12}
        alt=""
        src="../rectangle-351.svg"
      />
      <img className={styles.vectorIcon2} alt="" src="../vector2.svg" />
      <img
        className={styles.yellowRocketTakingOff}
        alt=""
        src="../yellow-rocket-taking-off@2x.png"
      />
      <button className={styles.launchingSoon}>Launching soon</button>
      <div className={styles.subscribeNewsletterParent}>
        <div className={styles.subscribeNewsletter}>Subscribe Newsletter</div>
        <textarea className={styles.rectangleTextarea} />
        <button className={styles.rectangle155defaultWrapper}>
          <button className={styles.vectorParent}>
            <button className={styles.rectangle155defaultChild} />
            <button className={styles.subscribe}>Subscribe</button>
          </button>
        </button>
        <textarea
          className={styles.enterYourEmail}
          placeholder="Enter your email id"
        />
        <img
          className={styles.securedLetterIcon}
          alt=""
          src="../secured-letter@2x.png"
        />
      </div>
      <div className={styles.email}>{`Email  `}</div>
      <textarea
        className={styles.enterYourEmail1}
        placeholder="Enter your email id here"
      />
      <div className={styles.problemStatement}>Problem statement</div>
      <textarea
        className={styles.problemStatementOf}
        placeholder=" Problem statement of your startup"
      />
      <div className={styles.solutionStatement}>Solution statement</div>
      <textarea
        className={styles.solutionStatementOf}
        placeholder=" Solution  statement of your startup"
      />
      <img
        className={styles.youngManOnlineConsultant}
        alt=""
        src="../young-man-online-consultant@2x.png"
      />
      <div className={styles.groupContainer}>
        <div className={styles.groupWrapper}>
          <div className={styles.groupDiv}>
            <div className={styles.rectangleWrapper}>
              <button className={styles.groupChild} />
            </div>
            <div className={styles.rectangleParent}>
              <button className={styles.groupItem} />
              <div className={styles.edtech}>EdTech</div>
            </div>
            <button className={styles.groupInner} />
            <div className={styles.ecommerce}>Ecommerce</div>
            <button className={styles.rectangleButton} />
            <div className={styles.saasTech}>SaaS-Tech</div>
            <button className={styles.groupChild1} />
            <div className={styles.healthTech}>Health Tech</div>
            <button className={styles.groupChild2} />
            <div className={styles.consumerTech}>Consumer Tech</div>
            <div className={styles.fintech}>FinTech</div>
          </div>
        </div>
        <button className={styles.rectangleGroup}>
          <button className={styles.groupChild3} />
          <div className={styles.selectDomain}>Select Domain</div>
          <img className={styles.vectorIcon3} alt="" src="../vector3.svg" />
        </button>
        <button className={styles.instanceChild1} />
        <div className={styles.enterpriseTech}>Enterprise Tech</div>
      </div>
    </div>
  );
};

export default Desktop2;
